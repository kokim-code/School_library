# School Library Web System

WEB-система хранения и перемещения книг в библиотеке школы.

## Реализованные разделы

- главная страница: `/`
- каталог книг: `/books`
- экземпляры книг: `/copies`
- читатели: `/readers`
- выдача и возврат: `/loans`
- перемещения книг: `/transfers`

## Стек

- .NET 8
- ASP.NET Core
- Blazor Server
- Entity Framework Core Code First
- PostgreSQL
- Docker и Docker Compose

## Запуск через Docker

```bash
docker compose up --build
```

После запуска открыть:

```text
http://localhost:8080
```

## Локальный запуск без Docker

Нужно запустить PostgreSQL и указать строку подключения в `appsettings.Development.json`.

```bash
dotnet restore
dotnet run --project SchoolLibrary.Web
```

## GitHub

https://github.com/kokim-code/school-library-web-system
